package com.petworld.service;

import com.petworld.command.PetVO;

public interface PetService {

	public boolean petRegist(PetVO vo);
	
}
