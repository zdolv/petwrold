package com.petworld.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
public class MainpageController {
	
	@RequestMapping("/mainpage")
	public void mainpage() {
		
	}

}
