package com.simple.test.mapper;

public interface TestMapper {

	public String getTime();
	
}
